const jq = require("jquery");

import Lasagne from './modules/Lasagne.js';

let lasagne = new Lasagne();
